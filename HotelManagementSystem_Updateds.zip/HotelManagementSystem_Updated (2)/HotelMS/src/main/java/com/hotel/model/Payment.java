package com.hotel.model;

import javafx.beans.property.*;

public class Payment {
    private IntegerProperty paymentId = new SimpleIntegerProperty();
    private IntegerProperty bookingId = new SimpleIntegerProperty();
    private DoubleProperty amount = new SimpleDoubleProperty();
    private StringProperty paymentDate = new SimpleStringProperty();
    private StringProperty paymentMethod = new SimpleStringProperty();
    private StringProperty customerName = new SimpleStringProperty();
    private StringProperty roomNumber = new SimpleStringProperty();

    public Payment() {}

    public int getPaymentId() { return paymentId.get(); }
    public IntegerProperty paymentIdProperty() { return paymentId; }
    public void setPaymentId(int v) { paymentId.set(v); }

    public int getBookingId() { return bookingId.get(); }
    public IntegerProperty bookingIdProperty() { return bookingId; }
    public void setBookingId(int v) { bookingId.set(v); }

    public double getAmount() { return amount.get(); }
    public DoubleProperty amountProperty() { return amount; }
    public void setAmount(double v) { amount.set(v); }

    public String getPaymentDate() { return paymentDate.get(); }
    public StringProperty paymentDateProperty() { return paymentDate; }
    public void setPaymentDate(String v) { paymentDate.set(v); }

    public String getPaymentMethod() { return paymentMethod.get(); }
    public StringProperty paymentMethodProperty() { return paymentMethod; }
    public void setPaymentMethod(String v) { paymentMethod.set(v); }

    public String getCustomerName() { return customerName.get(); }
    public StringProperty customerNameProperty() { return customerName; }
    public void setCustomerName(String v) { customerName.set(v); }

    public String getRoomNumber() { return roomNumber.get(); }
    public StringProperty roomNumberProperty() { return roomNumber; }
    public void setRoomNumber(String v) { roomNumber.set(v); }
}
