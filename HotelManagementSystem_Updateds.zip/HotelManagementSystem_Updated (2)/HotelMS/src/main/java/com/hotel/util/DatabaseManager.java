package com.hotel.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseManager {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/hms?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC&createDatabaseIfNotExist=true";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "123456";
    private static Connection connection;

    public static void initialize() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            createTables();
            seedData();
            System.out.println("Database initialized successfully.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Connection getConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }

    private static void createTables() throws SQLException {
        String users = """
            CREATE TABLE IF NOT EXISTS users (
                user_id INT PRIMARY KEY AUTO_INCREMENT,
                username VARCHAR(100) NOT NULL UNIQUE,
                password VARCHAR(100) NOT NULL,
                role ENUM('Admin','Staff') NOT NULL
            );
        """;
        String customers = """
            CREATE TABLE IF NOT EXISTS customers (
                customer_id INT PRIMARY KEY AUTO_INCREMENT,
                name VARCHAR(200) NOT NULL,
                phone VARCHAR(20) NOT NULL,
                email VARCHAR(200),
                address VARCHAR(300)
            );
        """;
        String rooms = """
            CREATE TABLE IF NOT EXISTS rooms (
                room_id INT PRIMARY KEY AUTO_INCREMENT,
                room_number VARCHAR(20) NOT NULL UNIQUE,
                room_type ENUM('Single','Double','Deluxe','Suite') NOT NULL,
                price DOUBLE NOT NULL,
                floor VARCHAR(50),
                status ENUM('Available','Booked','Maintenance') NOT NULL DEFAULT 'Available'
            );
        """;
        String bookings = """
            CREATE TABLE IF NOT EXISTS bookings (
                booking_id INT PRIMARY KEY AUTO_INCREMENT,
                customer_id INT NOT NULL,
                room_id INT NOT NULL,
                check_in_date VARCHAR(20) NOT NULL,
                check_out_date VARCHAR(20) NOT NULL,
                status ENUM('Confirmed','Cancelled','CheckedOut') NOT NULL DEFAULT 'Confirmed',
                FOREIGN KEY(customer_id) REFERENCES customers(customer_id),
                FOREIGN KEY(room_id) REFERENCES rooms(room_id)
            );
        """;
        String payments = """
            CREATE TABLE IF NOT EXISTS payments (
                payment_id INT PRIMARY KEY AUTO_INCREMENT,
                booking_id INT NOT NULL,
                amount DOUBLE NOT NULL,
                payment_date VARCHAR(20) NOT NULL,
                payment_method VARCHAR(50) NOT NULL DEFAULT 'Cash',
                FOREIGN KEY(booking_id) REFERENCES bookings(booking_id)
            );
        """;

        try (Statement stmt = connection.createStatement()) {
            stmt.execute(users);
            stmt.execute(customers);
            stmt.execute(rooms);
            stmt.execute(bookings);
            stmt.execute(payments);
        }
    }

    private static void seedData() throws SQLException {
        // Seed admin and staff users (INSERT IGNORE skips if username already exists)
        connection.createStatement().execute(
            "INSERT IGNORE INTO users(username,password,role) VALUES('admin','admin123','Admin')");
        connection.createStatement().execute(
            "INSERT IGNORE INTO users(username,password,role) VALUES('staff','staff123','Staff')");

        // Seed rooms if none
        String checkRooms = "SELECT COUNT(*) FROM rooms";
        try (Statement s = connection.createStatement();
             ResultSet rs = s.executeQuery(checkRooms)) {
            if (rs.next() && rs.getInt(1) == 0) {
                String[] inserts = {
                    "INSERT INTO rooms(room_number,room_type,price,floor,status) VALUES('101','Single',2000,'Floor 1','Available')",
                    "INSERT INTO rooms(room_number,room_type,price,floor,status) VALUES('102','Single',2000,'Floor 1','Available')",
                    "INSERT INTO rooms(room_number,room_type,price,floor,status) VALUES('103','Double',3500,'Floor 1','Available')",
                    "INSERT INTO rooms(room_number,room_type,price,floor,status) VALUES('201','Double',3500,'Floor 2','Available')",
                    "INSERT INTO rooms(room_number,room_type,price,floor,status) VALUES('202','Suite',6000,'Floor 2','Available')",
                    "INSERT INTO rooms(room_number,room_type,price,floor,status) VALUES('301','Suite',6000,'Floor 3','Maintenance')",
                    "INSERT INTO rooms(room_number,room_type,price,floor,status) VALUES('302','Deluxe',5000,'Floor 3','Available')",
                    "INSERT INTO rooms(room_number,room_type,price,floor,status) VALUES('401','Deluxe',5000,'Floor 4','Available')",
                };
                for (String sql : inserts) connection.createStatement().execute(sql);
            }
        }

        // Seed sample customers if none
        String checkCust = "SELECT COUNT(*) FROM customers";
        try (Statement s = connection.createStatement();
             ResultSet rs = s.executeQuery(checkCust)) {
            if (rs.next() && rs.getInt(1) == 0) {
                String[] custs = {
                    "INSERT INTO customers(name,phone,email,address) VALUES('Ram Sharma','9800000001','ram@gmail.com','Kathmandu')",
                    "INSERT INTO customers(name,phone,email,address) VALUES('Sita Rai','9800000002','sita@gmail.com','Pokhara')",
                    "INSERT INTO customers(name,phone,email,address) VALUES('Hari Thapa','9800000003','hari@gmail.com','Butwal')",
                };
                for (String sql : custs) connection.createStatement().execute(sql);
            }
        }
    }

    public static void close() {
        try {
            if (connection != null && !connection.isClosed()) connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
