package com.hotel.model;

import javafx.beans.property.*;

public class Booking {
    private IntegerProperty bookingId = new SimpleIntegerProperty();
    private IntegerProperty customerId = new SimpleIntegerProperty();
    private IntegerProperty roomId = new SimpleIntegerProperty();
    private StringProperty customerName = new SimpleStringProperty();
    private StringProperty roomNumber = new SimpleStringProperty();
    private StringProperty roomType = new SimpleStringProperty();
    private StringProperty checkInDate = new SimpleStringProperty();
    private StringProperty checkOutDate = new SimpleStringProperty();
    private StringProperty status = new SimpleStringProperty();
    private DoubleProperty totalAmount = new SimpleDoubleProperty();

    public Booking() {}

    public int getBookingId() { return bookingId.get(); }
    public IntegerProperty bookingIdProperty() { return bookingId; }
    public void setBookingId(int v) { bookingId.set(v); }

    public int getCustomerId() { return customerId.get(); }
    public IntegerProperty customerIdProperty() { return customerId; }
    public void setCustomerId(int v) { customerId.set(v); }

    public int getRoomId() { return roomId.get(); }
    public IntegerProperty roomIdProperty() { return roomId; }
    public void setRoomId(int v) { roomId.set(v); }

    public String getCustomerName() { return customerName.get(); }
    public StringProperty customerNameProperty() { return customerName; }
    public void setCustomerName(String v) { customerName.set(v); }

    public String getRoomNumber() { return roomNumber.get(); }
    public StringProperty roomNumberProperty() { return roomNumber; }
    public void setRoomNumber(String v) { roomNumber.set(v); }

    public String getRoomType() { return roomType.get(); }
    public StringProperty roomTypeProperty() { return roomType; }
    public void setRoomType(String v) { roomType.set(v); }

    public String getCheckInDate() { return checkInDate.get(); }
    public StringProperty checkInDateProperty() { return checkInDate; }
    public void setCheckInDate(String v) { checkInDate.set(v); }

    public String getCheckOutDate() { return checkOutDate.get(); }
    public StringProperty checkOutDateProperty() { return checkOutDate; }
    public void setCheckOutDate(String v) { checkOutDate.set(v); }

    public String getStatus() { return status.get(); }
    public StringProperty statusProperty() { return status; }
    public void setStatus(String v) { status.set(v); }

    public double getTotalAmount() { return totalAmount.get(); }
    public DoubleProperty totalAmountProperty() { return totalAmount; }
    public void setTotalAmount(double v) { totalAmount.set(v); }
}
