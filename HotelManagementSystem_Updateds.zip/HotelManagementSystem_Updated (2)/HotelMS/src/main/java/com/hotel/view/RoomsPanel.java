package com.hotel.view;

import com.hotel.dao.RoomDAO;
import com.hotel.model.Room;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;

public class RoomsPanel {

    private VBox root;
    private TableView<Room> table;
    private ObservableList<Room> roomData;
    private RoomDAO roomDAO = new RoomDAO();
    private TextField searchField;

    public RoomsPanel() { buildUI(); }

    private void buildUI() {
        root = new VBox(20);
        root.setPadding(new Insets(32));
        root.getStyleClass().add("panel-content");

        // Header row
        Label title = new Label("Room Management");
        title.getStyleClass().add("panel-title");
        Label sub = new Label("Manage all hotel rooms");
        sub.getStyleClass().add("panel-subtitle");

        HBox headerRow = new HBox(12);
        headerRow.setAlignment(Pos.CENTER_LEFT);
        searchField = new TextField();
        searchField.setPromptText("🔍  Search rooms...");
        searchField.getStyleClass().add("search-field");
        searchField.setPrefWidth(260);
        searchField.textProperty().addListener((o, ov, nv) -> filterRooms(nv));

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button addBtn = new Button("+ Add Room");
        addBtn.getStyleClass().add("btn-primary");
        addBtn.setOnAction(e -> showRoomDialog(null));

        headerRow.getChildren().addAll(searchField, spacer, addBtn);

        // Table
        table = new TableView<>();
        table.getStyleClass().add("data-table");
        VBox.setVgrow(table, Priority.ALWAYS);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<Room, Integer> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("roomId"));
        idCol.setMaxWidth(60);

        TableColumn<Room, String> numCol = new TableColumn<>("Room No.");
        numCol.setCellValueFactory(new PropertyValueFactory<>("roomNumber"));

        TableColumn<Room, String> typeCol = new TableColumn<>("Type");
        typeCol.setCellValueFactory(new PropertyValueFactory<>("roomType"));

        TableColumn<Room, String> floorCol = new TableColumn<>("Floor");
        floorCol.setCellValueFactory(new PropertyValueFactory<>("floor"));

        TableColumn<Room, Double> priceCol = new TableColumn<>("Price/Night");
        priceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        priceCol.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(Double item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : "Rs " + String.format("%,.0f", item));
            }
        });

        TableColumn<Room, String> statusCol = new TableColumn<>("Status");
        statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));
        statusCol.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setText(null); setGraphic(null); return; }
                Label lbl = new Label(item);
                String color = switch (item) {
                    case "Available" -> "#16a34a";
                    case "Booked"    -> "#dc2626";
                    default          -> "#d97706";
                };
                lbl.setStyle("-fx-text-fill:" + color +
                        "; -fx-background-color:" + color + "22;" +
                        "-fx-padding:3 10; -fx-background-radius:10; -fx-font-weight:bold; -fx-font-size:11px;");
                setGraphic(lbl); setText(null);
            }
        });

        TableColumn<Room, Void> actCol = new TableColumn<>("Actions");
        actCol.setCellFactory(col -> new TableCell<>() {
            final Button editBtn   = new Button("✏ Edit");
            final Button deleteBtn = new Button("🗑 Delete");
            { editBtn.getStyleClass().add("btn-sm-primary");
              deleteBtn.getStyleClass().add("btn-sm-danger"); }
            @Override protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) { setGraphic(null); return; }
                HBox box = new HBox(6, editBtn, deleteBtn);
                editBtn.setOnAction(e -> showRoomDialog(getTableView().getItems().get(getIndex())));
                deleteBtn.setOnAction(e -> deleteRoom(getTableView().getItems().get(getIndex())));
                setGraphic(box);
            }
        });

        table.getColumns().addAll(idCol, numCol, typeCol, floorCol, priceCol, statusCol, actCol);

        loadRooms();

        root.getChildren().addAll(new VBox(4, title, sub), headerRow, table);
    }

    private void loadRooms() {
        roomData = FXCollections.observableArrayList(roomDAO.getAllRooms());
        table.setItems(roomData);
    }

    private void filterRooms(String query) {
        if (query == null || query.isBlank()) { loadRooms(); return; }
        String q = query.toLowerCase();
        roomData = FXCollections.observableArrayList(
            roomDAO.getAllRooms().stream().filter(r ->
                r.getRoomNumber().toLowerCase().contains(q) ||
                r.getRoomType().toLowerCase().contains(q) ||
                r.getStatus().toLowerCase().contains(q)
            ).toList());
        table.setItems(roomData);
    }

    private void showRoomDialog(Room existing) {
        Dialog<Room> dialog = new Dialog<>();
        dialog.setTitle(existing == null ? "Add New Room" : "Edit Room");
        dialog.setHeaderText(null);

        ButtonType saveBtn = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveBtn, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(12); grid.setVgap(12);
        grid.setPadding(new Insets(20));

        TextField numField   = new TextField(existing != null ? existing.getRoomNumber() : "");
        ComboBox<String> typeBox = new ComboBox<>(FXCollections.observableArrayList("Single","Double","Deluxe","Suite"));
        typeBox.setValue(existing != null ? existing.getRoomType() : "Single");
        TextField priceField = new TextField(existing != null ? String.valueOf((int)existing.getPrice()) : "");
        TextField floorField = new TextField(existing != null ? existing.getFloor() : "");
        ComboBox<String> statusBox = new ComboBox<>(FXCollections.observableArrayList("Available","Booked","Maintenance"));
        statusBox.setValue(existing != null ? existing.getStatus() : "Available");

        for (Control c : new Control[]{numField, priceField, floorField}) ((TextField)c).getStyleClass().add("text-field-custom");
        typeBox.getStyleClass().add("combo-custom");
        statusBox.getStyleClass().add("combo-custom");

        grid.addRow(0, new Label("Room Number:"), numField);
        grid.addRow(1, new Label("Type:"), typeBox);
        grid.addRow(2, new Label("Price/Night:"), priceField);
        grid.addRow(3, new Label("Floor:"), floorField);
        grid.addRow(4, new Label("Status:"), statusBox);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getStylesheets().add(getClass().getResource("/styles/main.css").toExternalForm());

        dialog.setResultConverter(btn -> {
            if (btn == saveBtn) {
                try {
                    Room r = existing != null ? existing : new Room();
                    r.setRoomNumber(numField.getText().trim());
                    r.setRoomType(typeBox.getValue());
                    r.setPrice(Double.parseDouble(priceField.getText().trim()));
                    r.setFloor(floorField.getText().trim());
                    r.setStatus(statusBox.getValue());
                    return r;
                } catch (Exception ex) { return null; }
            }
            return null;
        });

        dialog.showAndWait().ifPresent(room -> {
            boolean ok = existing == null ? roomDAO.addRoom(room) : roomDAO.updateRoom(room);
            if (ok) { loadRooms(); showAlert(Alert.AlertType.INFORMATION, "Success", "Room saved successfully."); }
            else showAlert(Alert.AlertType.ERROR, "Error", "Could not save room. Room number may already exist.");
        });
    }

    private void deleteRoom(Room room) {
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                "Delete Room " + room.getRoomNumber() + "?", ButtonType.YES, ButtonType.NO);
        confirm.showAndWait().filter(r -> r == ButtonType.YES).ifPresent(r -> {
            if (roomDAO.deleteRoom(room.getRoomId())) loadRooms();
            else showAlert(Alert.AlertType.ERROR, "Error", "Cannot delete room with existing bookings.");
        });
    }

    private void showAlert(Alert.AlertType type, String title, String msg) {
        Alert a = new Alert(type, msg, ButtonType.OK);
        a.setTitle(title); a.setHeaderText(null); a.showAndWait();
    }

    public Parent getRoot() { return root; }
}
