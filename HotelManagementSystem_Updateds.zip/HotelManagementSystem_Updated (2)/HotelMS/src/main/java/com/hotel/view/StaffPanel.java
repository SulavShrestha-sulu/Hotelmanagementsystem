package com.hotel.view;

import com.hotel.dao.UserDAO;
import com.hotel.model.User;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;

public class StaffPanel {

    private VBox root;
    private TableView<User> table;
    private ObservableList<User> data;
    private UserDAO dao = new UserDAO();

    public StaffPanel() { buildUI(); }

    private void buildUI() {
        root = new VBox(20);
        root.setPadding(new Insets(32));
        root.getStyleClass().add("panel-content");

        Label title = new Label("Staff Management");
        title.getStyleClass().add("panel-title");
        Label sub = new Label("Admin only — add and manage staff accounts");
        sub.getStyleClass().add("panel-subtitle");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button addBtn = new Button("+ Add Staff");
        addBtn.getStyleClass().add("btn-primary");
        addBtn.setOnAction(e -> showDialog());

        HBox headerRow = new HBox(12, new VBox(4, title, sub), spacer, addBtn);
        headerRow.setAlignment(Pos.CENTER_LEFT);

        table = new TableView<>();
        table.getStyleClass().add("data-table");
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        VBox.setVgrow(table, Priority.ALWAYS);

        TableColumn<User, Integer> idCol = col("ID", "userId");
        idCol.setMaxWidth(70);
        TableColumn<User, String> nameCol = col("Username", "username");
        TableColumn<User, String> roleCol = col("Role", "role");
        roleCol.setMaxWidth(100);

        TableColumn<User, Void> actCol = new TableColumn<>("Actions");
        actCol.setMaxWidth(120);
        actCol.setCellFactory(c -> new TableCell<>() {
            final Button delBtn = new Button("🗑 Delete");
            { delBtn.getStyleClass().add("btn-sm-danger"); }
            @Override protected void updateItem(Void v, boolean empty) {
                super.updateItem(v, empty);
                if (empty) { setGraphic(null); return; }
                delBtn.setOnAction(e -> deleteStaff(getTableView().getItems().get(getIndex())));
                setGraphic(delBtn);
            }
        });

        table.getColumns().addAll(idCol, nameCol, roleCol, actCol);
        loadData();

        root.getChildren().addAll(headerRow, table);
    }

    @SuppressWarnings("unchecked")
    private <T> TableColumn<User, T> col(String label, String prop) {
        TableColumn<User, T> c = new TableColumn<>(label);
        c.setCellValueFactory(new PropertyValueFactory<>(prop));
        return c;
    }

    private void loadData() {
        data = FXCollections.observableArrayList(dao.getAllStaff());
        table.setItems(data);
    }

    private void showDialog() {
        Dialog<User> dialog = new Dialog<>();
        dialog.setTitle("Add Staff Account");
        dialog.setHeaderText(null);

        ButtonType saveType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(12); grid.setVgap(12);
        grid.setPadding(new Insets(20));

        TextField usernameF = new TextField();
        usernameF.setPromptText("Enter username");
        usernameF.getStyleClass().add("text-field-custom");
        usernameF.setPrefWidth(250);

        PasswordField passwordF = new PasswordField();
        passwordF.setPromptText("Enter password");
        passwordF.getStyleClass().add("text-field-custom");
        passwordF.setPrefWidth(250);

        PasswordField confirmF = new PasswordField();
        confirmF.setPromptText("Confirm password");
        confirmF.getStyleClass().add("text-field-custom");
        confirmF.setPrefWidth(250);

        Label errorLbl = new Label();
        errorLbl.setStyle("-fx-text-fill: #dc2626; -fx-font-size: 12px;");

        grid.addRow(0, new Label("Username:"), usernameF);
        grid.addRow(1, new Label("Password:"), passwordF);
        grid.addRow(2, new Label("Confirm Password:"), confirmF);
        grid.add(errorLbl, 0, 3, 2, 1);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getStylesheets().add(
                getClass().getResource("/styles/main.css").toExternalForm());

        // Disable save button until fields are filled
        javafx.scene.Node saveBtn = dialog.getDialogPane().lookupButton(saveType);
        saveBtn.setDisable(true);

        Runnable validate = () -> {
            String u = usernameF.getText().trim();
            String p = passwordF.getText();
            String c = confirmF.getText();
            boolean ok = !u.isEmpty() && !p.isEmpty() && !c.isEmpty();
            saveBtn.setDisable(!ok);
            if (!p.isEmpty() && !c.isEmpty() && !p.equals(c)) {
                errorLbl.setText("Passwords do not match.");
                saveBtn.setDisable(true);
            } else {
                errorLbl.setText("");
            }
        };

        usernameF.textProperty().addListener((o, ov, nv) -> validate.run());
        passwordF.textProperty().addListener((o, ov, nv) -> validate.run());
        confirmF.textProperty().addListener((o, ov, nv) -> validate.run());

        dialog.setResultConverter(btn -> {
            if (btn == saveType) {
                User u = new User();
                u.setUsername(usernameF.getText().trim());
                u.setPassword(passwordF.getText());
                u.setRole("Staff");
                return u;
            }
            return null;
        });

        dialog.showAndWait().ifPresent(u -> {
            if (dao.usernameExists(u.getUsername())) {
                showAlert(Alert.AlertType.WARNING, "Duplicate", "Username '" + u.getUsername() + "' already exists.");
                return;
            }
            if (dao.addUser(u)) {
                loadData();
                showAlert(Alert.AlertType.INFORMATION, "Success", "Staff account created successfully.");
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Could not create staff account.");
            }
        });
    }

    private void deleteStaff(User u) {
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                "Delete staff account: " + u.getUsername() + "?", ButtonType.YES, ButtonType.NO);
        confirm.setTitle("Confirm Delete");
        confirm.setHeaderText(null);
        confirm.showAndWait().filter(r -> r == ButtonType.YES).ifPresent(r -> {
            if (dao.deleteUser(u.getUserId())) loadData();
            else showAlert(Alert.AlertType.ERROR, "Error", "Could not delete staff account.");
        });
    }

    private void showAlert(Alert.AlertType type, String title, String msg) {
        Alert a = new Alert(type, msg, ButtonType.OK);
        a.setTitle(title); a.setHeaderText(null); a.showAndWait();
    }

    public Parent getRoot() { return root; }
}
