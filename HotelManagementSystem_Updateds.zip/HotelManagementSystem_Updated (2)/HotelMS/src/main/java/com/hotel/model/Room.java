package com.hotel.model;

import javafx.beans.property.*;

public class Room {
    private IntegerProperty roomId = new SimpleIntegerProperty();
    private StringProperty roomNumber = new SimpleStringProperty();
    private StringProperty roomType = new SimpleStringProperty();
    private DoubleProperty price = new SimpleDoubleProperty();
    private StringProperty floor = new SimpleStringProperty();
    private StringProperty status = new SimpleStringProperty();

    public Room() {}
    public Room(int roomId, String roomNumber, String roomType, double price, String floor, String status) {
        this.roomId.set(roomId); this.roomNumber.set(roomNumber);
        this.roomType.set(roomType); this.price.set(price);
        this.floor.set(floor); this.status.set(status);
    }

    public int getRoomId() { return roomId.get(); }
    public IntegerProperty roomIdProperty() { return roomId; }
    public void setRoomId(int v) { roomId.set(v); }

    public String getRoomNumber() { return roomNumber.get(); }
    public StringProperty roomNumberProperty() { return roomNumber; }
    public void setRoomNumber(String v) { roomNumber.set(v); }

    public String getRoomType() { return roomType.get(); }
    public StringProperty roomTypeProperty() { return roomType; }
    public void setRoomType(String v) { roomType.set(v); }

    public double getPrice() { return price.get(); }
    public DoubleProperty priceProperty() { return price; }
    public void setPrice(double v) { price.set(v); }

    public String getFloor() { return floor.get(); }
    public StringProperty floorProperty() { return floor; }
    public void setFloor(String v) { floor.set(v); }

    public String getStatus() { return status.get(); }
    public StringProperty statusProperty() { return status; }
    public void setStatus(String v) { status.set(v); }

    @Override public String toString() { return "Room " + roomNumber.get() + " (" + roomType.get() + ")"; }
}
