package com.hotel.dao;

import com.hotel.model.Customer;
import com.hotel.util.DatabaseManager;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CustomerDAO {

    public List<Customer> getAllCustomers() {
        List<Customer> list = new ArrayList<>();
        String sql = """
            SELECT c.*, COUNT(b.booking_id) as total_bookings
            FROM customers c
            LEFT JOIN bookings b ON c.customer_id = b.customer_id
            GROUP BY c.customer_id ORDER BY c.name
        """;
        try (Statement s = DatabaseManager.getConnection().createStatement();
             ResultSet rs = s.executeQuery(sql)) {
            while (rs.next()) {
                Customer c = mapRow(rs);
                c.setTotalBookings(rs.getInt("total_bookings"));
                list.add(c);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public boolean addCustomer(Customer customer) {
        String sql = "INSERT INTO customers(name,phone,email,address) VALUES(?,?,?,?)";
        try (PreparedStatement ps = DatabaseManager.getConnection().prepareStatement(sql)) {
            ps.setString(1, customer.getName());
            ps.setString(2, customer.getPhone());
            ps.setString(3, customer.getEmail());
            ps.setString(4, customer.getAddress());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public boolean updateCustomer(Customer customer) {
        String sql = "UPDATE customers SET name=?,phone=?,email=?,address=? WHERE customer_id=?";
        try (PreparedStatement ps = DatabaseManager.getConnection().prepareStatement(sql)) {
            ps.setString(1, customer.getName());
            ps.setString(2, customer.getPhone());
            ps.setString(3, customer.getEmail());
            ps.setString(4, customer.getAddress());
            ps.setInt(5, customer.getCustomerId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public boolean deleteCustomer(int customerId) {
        String sql = "DELETE FROM customers WHERE customer_id=?";
        try (PreparedStatement ps = DatabaseManager.getConnection().prepareStatement(sql)) {
            ps.setInt(1, customerId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); return false; }
    }

    public int totalCustomers() {
        String sql = "SELECT COUNT(*) FROM customers";
        try (Statement s = DatabaseManager.getConnection().createStatement();
             ResultSet rs = s.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    public List<Customer> searchCustomers(String query) {
        List<Customer> list = new ArrayList<>();
        String sql = """
            SELECT c.*, COUNT(b.booking_id) as total_bookings
            FROM customers c
            LEFT JOIN bookings b ON c.customer_id = b.customer_id
            WHERE c.name LIKE ? OR c.phone LIKE ? OR c.email LIKE ?
            GROUP BY c.customer_id ORDER BY c.name
        """;
        try (PreparedStatement ps = DatabaseManager.getConnection().prepareStatement(sql)) {
            String q = "%" + query + "%";
            ps.setString(1, q); ps.setString(2, q); ps.setString(3, q);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Customer c = mapRow(rs);
                c.setTotalBookings(rs.getInt("total_bookings"));
                list.add(c);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    private Customer mapRow(ResultSet rs) throws SQLException {
        return new Customer(rs.getInt("customer_id"), rs.getString("name"),
                rs.getString("phone"), rs.getString("email"), rs.getString("address"));
    }
}
