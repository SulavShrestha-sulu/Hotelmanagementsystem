package com.hotel.view;

import com.hotel.dao.BookingDAO;
import com.hotel.dao.CustomerDAO;
import com.hotel.dao.PaymentDAO;
import com.hotel.dao.RoomDAO;
import com.hotel.model.Booking;
import com.hotel.model.Customer;
import com.hotel.model.Payment;
import com.hotel.model.Room;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

public class BookingsPanel {

    private VBox root;
    private TableView<Booking> table;
    private ObservableList<Booking> data;
    private BookingDAO bookingDAO = new BookingDAO();
    private RoomDAO roomDAO = new RoomDAO();
    private CustomerDAO customerDAO = new CustomerDAO();
    private PaymentDAO paymentDAO = new PaymentDAO();

    public BookingsPanel() { buildUI(); }

    private void buildUI() {
        root = new VBox(20);
        root.setPadding(new Insets(32));
        root.getStyleClass().add("panel-content");

        Label title = new Label("Bookings");
        title.getStyleClass().add("panel-title");
        Label sub = new Label("Create and manage room reservations");
        sub.getStyleClass().add("panel-subtitle");

        Button newBtn = new Button("+ New Booking");
        newBtn.getStyleClass().add("btn-primary");
        newBtn.setOnAction(e -> showNewBookingDialog());

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        HBox headerRow = new HBox(12, spacer, newBtn);
        headerRow.setAlignment(Pos.CENTER_RIGHT);

        table = new TableView<>();
        table.getStyleClass().add("data-table");
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        VBox.setVgrow(table, Priority.ALWAYS);

        TableColumn<Booking, Integer> idCol = strCol("ID", "bookingId");
        idCol.setMaxWidth(60);
        TableColumn<Booking, String> custCol  = strCol("Customer", "customerName");
        TableColumn<Booking, String> roomCol  = strCol("Room", "roomNumber");
        TableColumn<Booking, String> typeCol  = strCol("Type", "roomType");
        TableColumn<Booking, String> inCol    = strCol("Check-In", "checkInDate");
        TableColumn<Booking, String> outCol   = strCol("Check-Out", "checkOutDate");

        TableColumn<Booking, Double> amtCol = new TableColumn<>("Amount");
        amtCol.setCellValueFactory(new PropertyValueFactory<>("totalAmount"));
        amtCol.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(Double v, boolean empty) {
                super.updateItem(v, empty);
                setText(empty || v == null ? null : "Rs " + String.format("%,.0f", v));
            }
        });

        TableColumn<Booking, String> statusCol = new TableColumn<>("Status");
        statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));
        statusCol.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setGraphic(null); return; }
                String color = switch (item) {
                    case "Confirmed"  -> "#16a34a";
                    case "Cancelled"  -> "#dc2626";
                    case "CheckedOut" -> "#0891b2";
                    default           -> "#64748b";
                };
                Label lbl = new Label(item);
                lbl.setStyle("-fx-text-fill:" + color + "; -fx-background-color:" + color +
                        "22; -fx-padding:3 10; -fx-background-radius:10; -fx-font-weight:bold; -fx-font-size:11px;");
                setGraphic(lbl); setText(null);
            }
        });

        TableColumn<Booking, Void> actCol = new TableColumn<>("Actions");
        actCol.setMinWidth(220);
        actCol.setCellFactory(col -> new TableCell<>() {
            final Button cancelBtn   = new Button("Cancel");
            final Button checkoutBtn = new Button("Check Out");
            final Button payBtn      = new Button("💳 Pay");
            {
                cancelBtn.getStyleClass().add("btn-sm-danger");
                checkoutBtn.getStyleClass().add("btn-sm-info");
                payBtn.getStyleClass().add("btn-sm-primary");
            }
            @Override protected void updateItem(Void v, boolean empty) {
                super.updateItem(v, empty);
                if (empty) { setGraphic(null); return; }
                Booking b = getTableView().getItems().get(getIndex());
                HBox box = new HBox(6);
                if ("Confirmed".equals(b.getStatus())) {
                    cancelBtn.setOnAction(e -> cancelBooking(b));
                    checkoutBtn.setOnAction(e -> checkoutBooking(b));
                    payBtn.setOnAction(e -> showPaymentDialog(b));
                    box.getChildren().addAll(payBtn, checkoutBtn, cancelBtn);
                }
                setGraphic(box);
            }
        });

        table.getColumns().addAll(idCol, custCol, roomCol, typeCol, inCol, outCol, amtCol, statusCol, actCol);
        loadData();

        root.getChildren().addAll(new VBox(4, title, sub), headerRow, table);
    }

    @SuppressWarnings("unchecked")
    private <T> TableColumn<Booking, T> strCol(String label, String prop) {
        TableColumn<Booking, T> c = new TableColumn<>(label);
        c.setCellValueFactory(new PropertyValueFactory<>(prop));
        return c;
    }

    private void loadData() {
        data = FXCollections.observableArrayList(bookingDAO.getAllBookings());
        table.setItems(data);
    }

    private void showNewBookingDialog() {
        List<Customer> customers = customerDAO.getAllCustomers();
        List<Room> availableRooms = roomDAO.getAvailableRooms();

        if (customers.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "No Customers", "Please add a customer first.");
            return;
        }
        if (availableRooms.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "No Rooms", "No available rooms at the moment.");
            return;
        }

        Dialog<Booking> dialog = new Dialog<>();
        dialog.setTitle("Create New Booking");
        dialog.setHeaderText(null);
        ButtonType saveType = new ButtonType("Create Booking", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(14); grid.setVgap(14);
        grid.setPadding(new Insets(24));

        ComboBox<Customer> custBox = new ComboBox<>(FXCollections.observableArrayList(customers));
        custBox.setPromptText("Select customer");
        custBox.getStyleClass().add("combo-custom");
        custBox.setMaxWidth(Double.MAX_VALUE);

        ComboBox<Room> roomBox = new ComboBox<>(FXCollections.observableArrayList(availableRooms));
        roomBox.setPromptText("Select room");
        roomBox.getStyleClass().add("combo-custom");
        roomBox.setMaxWidth(Double.MAX_VALUE);

        DatePicker checkIn  = new DatePicker(LocalDate.now());
        DatePicker checkOut = new DatePicker(LocalDate.now().plusDays(1));
        checkIn.getStyleClass().add("date-picker-custom");
        checkOut.getStyleClass().add("date-picker-custom");
        checkIn.setMaxWidth(Double.MAX_VALUE);
        checkOut.setMaxWidth(Double.MAX_VALUE);

        Label summaryLbl = new Label("Select room and dates to see total.");
        summaryLbl.setStyle("-fx-text-fill:#4f46e5; -fx-font-weight:bold; -fx-font-size:13px;");

        Runnable updateSummary = () -> {
            Room r = roomBox.getValue();
            LocalDate in = checkIn.getValue();
            LocalDate out = checkOut.getValue();
            if (r != null && in != null && out != null && out.isAfter(in)) {
                long nights = ChronoUnit.DAYS.between(in, out);
                double total = r.getPrice() * nights;
                summaryLbl.setText(String.format("Room %s  •  %d night(s)  •  Total: Rs %,.0f",
                        r.getRoomNumber(), nights, total));
            }
        };
        roomBox.setOnAction(e -> updateSummary.run());
        checkIn.setOnAction(e -> updateSummary.run());
        checkOut.setOnAction(e -> updateSummary.run());

        grid.addRow(0, new Label("Customer:"), custBox);
        grid.addRow(1, new Label("Room:"), roomBox);
        grid.addRow(2, new Label("Check-In Date:"), checkIn);
        grid.addRow(3, new Label("Check-Out Date:"), checkOut);
        grid.add(summaryLbl, 0, 4, 2, 1);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getStylesheets().add(getClass().getResource("/styles/main.css").toExternalForm());
        dialog.getDialogPane().setPrefWidth(440);

        dialog.setResultConverter(btn -> {
            if (btn == saveType) {
                if (custBox.getValue() == null || roomBox.getValue() == null) return null;
                LocalDate in = checkIn.getValue(), out = checkOut.getValue();
                if (in == null || out == null || !out.isAfter(in)) return null;
                Booking b = new Booking();
                b.setCustomerId(custBox.getValue().getCustomerId());
                b.setRoomId(roomBox.getValue().getRoomId());
                b.setCheckInDate(in.toString());
                b.setCheckOutDate(out.toString());
                return b;
            }
            return null;
        });

        dialog.showAndWait().ifPresent(b -> {
            if (bookingDAO.addBooking(b)) {
                loadData();
                showAlert(Alert.AlertType.INFORMATION, "Success", "Booking created successfully!");
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Could not create booking.");
            }
        });
    }

    private void showPaymentDialog(Booking booking) {
        Dialog<Payment> dialog = new Dialog<>();
        dialog.setTitle("Process Payment");
        dialog.setHeaderText("Booking #" + booking.getBookingId() + " — " + booking.getCustomerName());
        ButtonType payType = new ButtonType("Process Payment", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(payType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(12); grid.setVgap(12);
        grid.setPadding(new Insets(20));

        TextField amountField = new TextField(String.format("%.0f", booking.getTotalAmount()));
        amountField.getStyleClass().add("text-field-custom");

        ComboBox<String> methodBox = new ComboBox<>(FXCollections.observableArrayList("Cash","Card","Online Transfer","Cheque"));
        methodBox.setValue("Cash");
        methodBox.getStyleClass().add("combo-custom");

        grid.addRow(0, new Label("Amount (Rs):"), amountField);
        grid.addRow(1, new Label("Method:"), methodBox);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getStylesheets().add(getClass().getResource("/styles/main.css").toExternalForm());

        dialog.setResultConverter(btn -> {
            if (btn == payType) {
                try {
                    Payment p = new Payment();
                    p.setBookingId(booking.getBookingId());
                    p.setAmount(Double.parseDouble(amountField.getText().trim()));
                    p.setPaymentMethod(methodBox.getValue());
                    return p;
                } catch (Exception ex) { return null; }
            }
            return null;
        });

        dialog.showAndWait().ifPresent(p -> {
            if (paymentDAO.addPayment(p))
                showAlert(Alert.AlertType.INFORMATION, "Payment", "Payment of Rs " +
                        String.format("%,.0f", p.getAmount()) + " recorded successfully!");
            else showAlert(Alert.AlertType.ERROR, "Error", "Payment could not be recorded.");
        });
    }

    private void cancelBooking(Booking b) {
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                "Cancel booking for " + b.getCustomerName() + "?", ButtonType.YES, ButtonType.NO);
        confirm.showAndWait().filter(r -> r == ButtonType.YES).ifPresent(r -> {
            if (bookingDAO.cancelBooking(b.getBookingId(), b.getRoomId())) loadData();
            else showAlert(Alert.AlertType.ERROR, "Error", "Could not cancel booking.");
        });
    }

    private void checkoutBooking(Booking b) {
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                "Check out " + b.getCustomerName() + " from Room " + b.getRoomNumber() + "?",
                ButtonType.YES, ButtonType.NO);
        confirm.showAndWait().filter(r -> r == ButtonType.YES).ifPresent(r -> {
            if (bookingDAO.checkoutBooking(b.getBookingId(), b.getRoomId())) {
                loadData();
                showAlert(Alert.AlertType.INFORMATION, "Checked Out", "Guest checked out. Room is now available.");
            }
        });
    }

    private void showAlert(Alert.AlertType type, String title, String msg) {
        Alert a = new Alert(type, msg, ButtonType.OK);
        a.setTitle(title); a.setHeaderText(null); a.showAndWait();
    }

    public Parent getRoot() { return root; }
}
