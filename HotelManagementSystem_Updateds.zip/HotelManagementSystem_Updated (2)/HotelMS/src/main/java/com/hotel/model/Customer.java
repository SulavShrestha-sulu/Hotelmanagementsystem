package com.hotel.model;

import javafx.beans.property.*;

public class Customer {
    private IntegerProperty customerId = new SimpleIntegerProperty();
    private StringProperty name = new SimpleStringProperty();
    private StringProperty phone = new SimpleStringProperty();
    private StringProperty email = new SimpleStringProperty();
    private StringProperty address = new SimpleStringProperty();
    private IntegerProperty totalBookings = new SimpleIntegerProperty();

    public Customer() {}
    public Customer(int customerId, String name, String phone, String email, String address) {
        this.customerId.set(customerId); this.name.set(name);
        this.phone.set(phone); this.email.set(email); this.address.set(address);
    }

    public int getCustomerId() { return customerId.get(); }
    public IntegerProperty customerIdProperty() { return customerId; }
    public void setCustomerId(int v) { customerId.set(v); }

    public String getName() { return name.get(); }
    public StringProperty nameProperty() { return name; }
    public void setName(String v) { name.set(v); }

    public String getPhone() { return phone.get(); }
    public StringProperty phoneProperty() { return phone; }
    public void setPhone(String v) { phone.set(v); }

    public String getEmail() { return email.get(); }
    public StringProperty emailProperty() { return email; }
    public void setEmail(String v) { email.set(v); }

    public String getAddress() { return address.get(); }
    public StringProperty addressProperty() { return address; }
    public void setAddress(String v) { address.set(v); }

    public int getTotalBookings() { return totalBookings.get(); }
    public IntegerProperty totalBookingsProperty() { return totalBookings; }
    public void setTotalBookings(int v) { totalBookings.set(v); }

    @Override public String toString() { return name.get() + " (" + phone.get() + ")"; }
}
