package com.hotel.dao;

import com.hotel.model.Booking;
import com.hotel.util.DatabaseManager;

import java.sql.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

public class BookingDAO {

    public List<Booking> getAllBookings() {
        List<Booking> list = new ArrayList<>();
        String sql = """
            SELECT b.*, c.name as customer_name, r.room_number, r.room_type, r.price
            FROM bookings b
            JOIN customers c ON b.customer_id = c.customer_id
            JOIN rooms r ON b.room_id = r.room_id
            ORDER BY b.booking_id DESC
        """;
        try (Statement s = DatabaseManager.getConnection().createStatement();
             ResultSet rs = s.executeQuery(sql)) {
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    public boolean addBooking(Booking booking) {
        String sql = "INSERT INTO bookings(customer_id,room_id,check_in_date,check_out_date,status) VALUES(?,?,?,?,?)";
        try (PreparedStatement ps = DatabaseManager.getConnection().prepareStatement(sql)) {
            ps.setInt(1, booking.getCustomerId());
            ps.setInt(2, booking.getRoomId());
            ps.setString(3, booking.getCheckInDate());
            ps.setString(4, booking.getCheckOutDate());
            ps.setString(5, "Confirmed");
            int rows = ps.executeUpdate();
            if (rows > 0) {
                // Update room status to Booked
                new RoomDAO().updateStatus(booking.getRoomId(), "Booked");
                return true;
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public boolean cancelBooking(int bookingId, int roomId) {
        String sql = "UPDATE bookings SET status='Cancelled' WHERE booking_id=?";
        try (PreparedStatement ps = DatabaseManager.getConnection().prepareStatement(sql)) {
            ps.setInt(1, bookingId);
            if (ps.executeUpdate() > 0) {
                new RoomDAO().updateStatus(roomId, "Available");
                return true;
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public boolean checkoutBooking(int bookingId, int roomId) {
        String sql = "UPDATE bookings SET status='CheckedOut' WHERE booking_id=?";
        try (PreparedStatement ps = DatabaseManager.getConnection().prepareStatement(sql)) {
            ps.setInt(1, bookingId);
            if (ps.executeUpdate() > 0) {
                new RoomDAO().updateStatus(roomId, "Available");
                return true;
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

    public int totalBookings() {
        String sql = "SELECT COUNT(*) FROM bookings";
        try (Statement s = DatabaseManager.getConnection().createStatement();
             ResultSet rs = s.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    public int todayBookings() {
        String sql = "SELECT COUNT(*) FROM bookings WHERE check_in_date = ?";
        try (PreparedStatement ps = DatabaseManager.getConnection().prepareStatement(sql)) {
            ps.setString(1, LocalDate.now().toString());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    public double totalRevenue() {
        String sql = "SELECT COALESCE(SUM(amount),0) FROM payments";
        try (Statement s = DatabaseManager.getConnection().createStatement();
             ResultSet rs = s.executeQuery(sql)) {
            if (rs.next()) return rs.getDouble(1);
        } catch (SQLException e) { e.printStackTrace(); }
        return 0;
    }

    public List<Booking> getRecentBookings(int limit) {
        List<Booking> list = new ArrayList<>();
        String sql = """
            SELECT b.*, c.name as customer_name, r.room_number, r.room_type, r.price
            FROM bookings b
            JOIN customers c ON b.customer_id = c.customer_id
            JOIN rooms r ON b.room_id = r.room_id
            ORDER BY b.booking_id DESC LIMIT ?
        """;
        try (PreparedStatement ps = DatabaseManager.getConnection().prepareStatement(sql)) {
            ps.setInt(1, limit);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }

    private Booking mapRow(ResultSet rs) throws SQLException {
        Booking b = new Booking();
        b.setBookingId(rs.getInt("booking_id"));
        b.setCustomerId(rs.getInt("customer_id"));
        b.setRoomId(rs.getInt("room_id"));
        b.setCustomerName(rs.getString("customer_name"));
        b.setRoomNumber(rs.getString("room_number"));
        b.setRoomType(rs.getString("room_type"));
        b.setCheckInDate(rs.getString("check_in_date"));
        b.setCheckOutDate(rs.getString("check_out_date"));
        b.setStatus(rs.getString("status"));
        // Calculate total from price * nights
        double price = rs.getDouble("price");
        try {
            LocalDate in = LocalDate.parse(rs.getString("check_in_date"));
            LocalDate out = LocalDate.parse(rs.getString("check_out_date"));
            long nights = ChronoUnit.DAYS.between(in, out);
            b.setTotalAmount(price * Math.max(1, nights));
        } catch (Exception e) { b.setTotalAmount(price); }
        return b;
    }
}
