package com.hotel.view;

import com.hotel.dao.UserDAO;
import com.hotel.model.User;
import com.hotel.util.SessionManager;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.*;
import javafx.stage.Stage;

public class LoginView {

    private VBox root;
    private Stage stage;

    public LoginView(Stage stage) {
        this.stage = stage;
        buildUI();
    }

    private void buildUI() {
        root = new VBox(20);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(50, 60, 50, 60));
        root.getStyleClass().add("login-root");

        // Logo / Icon Area
        Label icon = new Label("🏨");
        icon.setStyle("-fx-font-size: 52px;");

        Label title = new Label("Hotel Management System");
        title.getStyleClass().add("login-title");

        Label subtitle = new Label("Sign in to access your dashboard");
        subtitle.getStyleClass().add("login-subtitle");

        VBox header = new VBox(6, icon, title, subtitle);
        header.setAlignment(Pos.CENTER);

        // Form
        Label userLabel = new Label("Username");
        userLabel.getStyleClass().add("field-label");
        TextField userField = new TextField();
        userField.setPromptText("Enter your username");
        userField.getStyleClass().add("text-field-custom");

        Label passLabel = new Label("Password");
        passLabel.getStyleClass().add("field-label");
        PasswordField passField = new PasswordField();
        passField.setPromptText("Enter your password");
        passField.getStyleClass().add("text-field-custom");

        Label errorLabel = new Label("");
        errorLabel.setStyle("-fx-text-fill: #e74c3c; -fx-font-size: 12px;");

        Button loginBtn = new Button("Sign In");
        loginBtn.getStyleClass().add("btn-primary");
        loginBtn.setMaxWidth(Double.MAX_VALUE);

        Label hint = new Label();
        hint.setStyle("-fx-text-fill: #888; -fx-font-size: 11px;");
        hint.setAlignment(Pos.CENTER);

        loginBtn.setOnAction(e -> {
            String u = userField.getText().trim();
            String p = passField.getText().trim();
            if (u.isEmpty() || p.isEmpty()) {
                errorLabel.setText("Please enter username and password.");
                return;
            }
            UserDAO dao = new UserDAO();
            User user = dao.authenticate(u, p);
            if (user != null) {
                SessionManager.setCurrentUser(user);
                openDashboard();
            } else {
                errorLabel.setText("Invalid username or password.");
            }
        });

        // Allow Enter key on password
        passField.setOnAction(e -> loginBtn.fire());

        VBox form = new VBox(8, userLabel, userField, passLabel, passField, errorLabel, loginBtn, hint);
        form.getStyleClass().add("login-card");
        form.setPadding(new Insets(30));

        root.getChildren().addAll(header, form);
    }

    private void openDashboard() {
        DashboardView dashboard = new DashboardView(stage);
        Scene scene = new Scene(dashboard.getRoot(), 1100, 720);
        scene.getStylesheets().add(getClass().getResource("/styles/main.css").toExternalForm());
        stage.setScene(scene);
        stage.setResizable(true);
        stage.setMinWidth(900);
        stage.setMinHeight(600);
    }

    public Parent getRoot() { return root; }
}
