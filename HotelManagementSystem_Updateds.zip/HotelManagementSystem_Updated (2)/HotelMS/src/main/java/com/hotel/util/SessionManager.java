package com.hotel.util;

import com.hotel.model.User;

public class SessionManager {
    private static User currentUser;

    public static void setCurrentUser(User user) { currentUser = user; }
    public static User getCurrentUser() { return currentUser; }
    public static void logout() { currentUser = null; }
    public static boolean isAdmin() {
        return currentUser != null && "Admin".equals(currentUser.getRole());
    }
}
