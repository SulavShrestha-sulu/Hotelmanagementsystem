module com.hotel {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;
    requires java.sql;
    requires java.logging;

    opens com.hotel to javafx.fxml;
    opens com.hotel.model to javafx.base;
    opens com.hotel.view to javafx.fxml;

    exports com.hotel;
    exports com.hotel.model;
    exports com.hotel.view;
    exports com.hotel.dao;
    exports com.hotel.util;
}
