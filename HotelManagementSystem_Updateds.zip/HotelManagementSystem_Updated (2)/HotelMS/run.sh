#!/bin/bash
echo "========================================"
echo "  Hotel Management System - Build & Run"
echo "========================================"
echo ""

if ! command -v mvn &> /dev/null; then
    echo "ERROR: Maven not found. Install it first:"
    echo "  Ubuntu/Debian: sudo apt install maven"
    echo "  Mac:           brew install maven"
    exit 1
fi

if ! command -v java &> /dev/null; then
    echo "ERROR: Java not found. Install JDK 21+:"
    echo "  Ubuntu/Debian: sudo apt install openjdk-21-jdk"
    echo "  Mac:           brew install openjdk@21"
    exit 1
fi

echo "Building project..."
mvn clean package -q

if [ $? -ne 0 ]; then
    echo "BUILD FAILED."
    exit 1
fi

echo "Launching Hotel Management System..."
mvn javafx:run
