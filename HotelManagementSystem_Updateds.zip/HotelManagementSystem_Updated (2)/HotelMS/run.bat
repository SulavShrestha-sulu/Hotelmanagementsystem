@echo off
echo ========================================
echo   Hotel Management System - Build & Run
echo ========================================
echo.

where mvn >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo ERROR: Maven not found. Please install Maven and add it to PATH.
    echo Download from: https://maven.apache.org/download.cgi
    pause
    exit /b 1
)

where java >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo ERROR: Java not found. Please install JDK 21+.
    echo Download from: https://adoptium.net/
    pause
    exit /b 1
)

echo Building the project...
call mvn clean package -q

if %ERRORLEVEL% NEQ 0 (
    echo BUILD FAILED. Check the error messages above.
    pause
    exit /b 1
)

echo Build successful! Launching application...
call mvn javafx:run

pause
