# 🏨 Hotel Management System
**JavaFX + SQLite Desktop Application**

Developed for: Sulav Shrestha | Roll: 2542181 | University of Bedfordshire  
Course: Principles of Programming | Assignment 2 — System Analysis and Design

---

## 📋 Features

| Module | Description |
|--------|-------------|
| 🔐 **Login** | Secure login for Admin and Staff roles |
| 🏠 **Dashboard** | Overview: stats cards, quick actions, recent bookings |
| 🛏 **Room Management** | Add, edit, delete rooms; status tracking |
| 👤 **Customer Management** | Full CRUD for guests with search |
| 📅 **Bookings** | Create bookings, cancel, check-out, process payments |
| 📊 **Reports** | Revenue, occupancy rate, booking stats, payment history |

---

## 🛠 Tech Stack

| Layer | Technology |
|-------|-----------|
| Language | Java 21 |
| GUI Framework | JavaFX 21 |
| Database | SQLite (via xerial sqlite-jdbc) |
| Build Tool | Maven |
| Architecture | MVC Pattern |
| Design Tool | (Figma prototype replicated in JavaFX) |

---

## 📁 Project Structure

```
HotelMS/
├── pom.xml                          # Maven build file
├── run.bat                          # Windows launcher
├── run.sh                           # Linux/Mac launcher
├── README.md
└── src/main/
    ├── java/
    │   ├── module-info.java
    │   └── com/hotel/
    │       ├── Main.java             # App entry point
    │       ├── model/                # Data models (Room, Customer, Booking, Payment, User)
    │       ├── dao/                  # Database access (RoomDAO, CustomerDAO, BookingDAO, PaymentDAO, UserDAO)
    │       ├── util/                 # DatabaseManager, SessionManager
    │       └── view/                 # UI panels (Login, Dashboard, Home, Rooms, Customers, Bookings, Reports)
    └── resources/
        └── styles/
            └── main.css             # Full dark-sidebar, card-based UI theme
```

---

## 🚀 How to Run

### Prerequisites
- Java JDK 21 or higher → https://adoptium.net/
- Apache Maven 3.8+ → https://maven.apache.org/

### Windows
```bash
run.bat
```

### Linux / macOS
```bash
chmod +x run.sh
./run.sh
```

### Manual (any OS)
```bash
cd HotelMS
mvn clean package
mvn javafx:run
```

---

## 🔑 Default Login Credentials

| Role | Username | Password |
|------|----------|----------|
| Admin | `admin` | `admin123` |
| Staff | `staff` | `staff123` |

---

## 🗄 Database Schema (SQLite — 3NF)

The database `hotel_management.db` is auto-created on first run.

### Tables

**users** — Authentication  
`user_id | username | password | role`

**customers** — Guest registry (3NF - no transitive deps)  
`customer_id | name | phone | email | address`

**rooms** — Room inventory  
`room_id | room_number | room_type | price | floor | status`

**bookings** — Reservation records (FK to customers + rooms)  
`booking_id | customer_id(FK) | room_id(FK) | check_in_date | check_out_date | status`

**payments** — Financial records (FK to bookings)  
`payment_id | booking_id(FK) | amount | payment_date | payment_method`

---

## 📐 Design Patterns Used

- **MVC** — Model/View separation with DAO layer as controller
- **DAO Pattern** — Database logic fully isolated in DAO classes
- **Singleton** — DatabaseManager maintains one shared connection
- **Observer** — JavaFX Property binding for live table updates

---

## 🗂 Sample Data (auto-seeded on first run)

**Rooms:** 8 rooms across 4 floors (Single, Double, Deluxe, Suite)  
**Customers:** 3 sample customers (Ram Sharma, Sita Rai, Hari Thapa)  
**Users:** admin + staff accounts

---

## 📖 Academic References

- Java SE 21 Documentation — https://docs.oracle.com/en/java/javase/21/
- JavaFX 21 API — https://openjfx.io/javadoc/21/
- SQLite Documentation — https://www.sqlite.org/docs.html
- Sommerville, I. (2016). *Software Engineering* (10th ed.). Pearson.
