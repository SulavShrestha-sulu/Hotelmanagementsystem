package com.hotel.view;

import com.hotel.dao.CustomerDAO;
import com.hotel.model.Customer;
import com.hotel.util.SessionManager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;

public class CustomersPanel {

    private VBox root;
    private TableView<Customer> table;
    private ObservableList<Customer> data;
    private CustomerDAO dao = new CustomerDAO();
    private TextField searchField;

    public CustomersPanel() { buildUI(); }

    private void buildUI() {
        root = new VBox(20);
        root.setPadding(new Insets(32));
        root.getStyleClass().add("panel-content");

        Label title = new Label("Customer Management");
        title.getStyleClass().add("panel-title");
        Label sub = new Label("Manage all customer information and records");
        sub.getStyleClass().add("panel-subtitle");

        searchField = new TextField();
        searchField.setPromptText("🔍  Search by name, email, phone...");
        searchField.getStyleClass().add("search-field");
        searchField.setPrefWidth(300);
        searchField.textProperty().addListener((o, ov, nv) -> filterCustomers(nv));

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button addBtn = new Button("+ Add Customer");
        addBtn.getStyleClass().add("btn-primary");
        addBtn.setOnAction(e -> showDialog(null));

        HBox headerRow = new HBox(12, searchField, spacer, addBtn);
        headerRow.setAlignment(Pos.CENTER_LEFT);

        table = new TableView<>();
        table.getStyleClass().add("data-table");
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        VBox.setVgrow(table, Priority.ALWAYS);

        TableColumn<Customer, Integer> idCol   = col("ID",             "customerId");
        idCol.setMaxWidth(60);
        TableColumn<Customer, String>  nameCol = col("Name",           "name");
        TableColumn<Customer, String>  phoneCol= col("Phone",          "phone");
        TableColumn<Customer, String>  emailCol= col("Email",          "email");
        TableColumn<Customer, String>  addrCol = col("Address",        "address");
        TableColumn<Customer, Integer> bookCol = col("Total Bookings", "totalBookings");
        bookCol.setMaxWidth(130);

        TableColumn<Customer, Void> actCol = new TableColumn<>("Actions");
        actCol.setCellFactory(c -> new TableCell<>() {
            final Button editBtn = new Button("✏ Edit");
            final Button delBtn  = new Button("🗑");
            { editBtn.getStyleClass().add("btn-sm-primary");
              delBtn.getStyleClass().add("btn-sm-danger"); }
            @Override protected void updateItem(Void v, boolean empty) {
                super.updateItem(v, empty);
                if (empty) { setGraphic(null); return; }
                Customer cust = getTableView().getItems().get(getIndex());
                editBtn.setOnAction(e -> showDialog(cust));
                delBtn.setOnAction(e  -> deleteCustomer(cust));
                setGraphic(new HBox(6, editBtn, delBtn));
            }
        });

        table.getColumns().addAll(idCol, nameCol, phoneCol, emailCol, addrCol, bookCol, actCol);
        loadData();

        root.getChildren().addAll(new VBox(4, title, sub), headerRow, table);
    }

    @SuppressWarnings("unchecked")
    private <T> TableColumn<Customer, T> col(String label, String prop) {
        TableColumn<Customer, T> c = new TableColumn<>(label);
        c.setCellValueFactory(new PropertyValueFactory<>(prop));
        return c;
    }

    private void loadData() {
        data = FXCollections.observableArrayList(dao.getAllCustomers());
        table.setItems(data);
    }

    private void filterCustomers(String query) {
        if (query == null || query.isBlank()) { loadData(); return; }
        data = FXCollections.observableArrayList(dao.searchCustomers(query));
        table.setItems(data);
    }

    private void showDialog(Customer existing) {
        Dialog<Customer> dialog = new Dialog<>();
        dialog.setTitle(existing == null ? "Add Customer" : "Edit Customer");
        dialog.setHeaderText(null);

        ButtonType saveType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(12); grid.setVgap(10);
        grid.setPadding(new Insets(20));

        TextField nameF  = styledField(existing != null ? existing.getName()    : "", "Full name *");
        TextField phoneF = styledField(existing != null ? existing.getPhone()   : "", "Phone number *");
        TextField emailF = styledField(existing != null ? existing.getEmail()   : "", "Email address");
        TextField addrF  = styledField(existing != null ? existing.getAddress() : "", "Address");

        // Inline error labels
        Label nameErr  = errLabel();
        Label phoneErr = errLabel();
        Label emailErr = errLabel();

        grid.addRow(0, boldLabel("Full Name *"),  nameF);
        grid.add(nameErr,  1, 1);
        grid.addRow(2, boldLabel("Phone *"),      phoneF);
        grid.add(phoneErr, 1, 3);
        grid.addRow(4, boldLabel("Email"),        emailF);
        grid.add(emailErr, 1, 5);
        grid.addRow(6, boldLabel("Address"),      addrF);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().setMinWidth(420);
        dialog.getDialogPane().getStylesheets().add(
                getClass().getResource("/styles/main.css").toExternalForm());

        // Disable save until required fields valid
        Node saveBtn = dialog.getDialogPane().lookupButton(saveType);
        saveBtn.setDisable(true);

        Runnable validate = () -> {
            boolean nameOk  = !nameF.getText().trim().isEmpty();
            boolean phoneOk = !phoneF.getText().trim().isEmpty();
            boolean emailOk = emailF.getText().trim().isEmpty()
                    || emailF.getText().trim().matches("^[\\w.+\\-]+@[\\w\\-]+\\.[a-zA-Z]{2,}$");

            nameErr.setText(nameOk   ? ""  : "Name is required.");
            phoneErr.setText(phoneOk ? ""  : "Phone is required.");
            emailErr.setText(emailOk ? ""  : "Invalid email format.");

            saveBtn.setDisable(!nameOk || !phoneOk || !emailOk);
        };

        nameF.textProperty().addListener((o, ov, nv)  -> validate.run());
        phoneF.textProperty().addListener((o, ov, nv) -> validate.run());
        emailF.textProperty().addListener((o, ov, nv) -> validate.run());

        dialog.setResultConverter(btn -> {
            if (btn == saveType) {
                Customer c = existing != null ? existing : new Customer();
                c.setName(nameF.getText().trim());
                c.setPhone(phoneF.getText().trim());
                c.setEmail(emailF.getText().trim());
                c.setAddress(addrF.getText().trim());
                return c;
            }
            return null;
        });

        dialog.showAndWait().ifPresent(c -> {
            boolean ok = existing == null ? dao.addCustomer(c) : dao.updateCustomer(c);
            if (ok) { loadData(); showAlert(Alert.AlertType.INFORMATION, "Success", "Customer saved successfully."); }
            else    { showAlert(Alert.AlertType.ERROR, "Error", "Could not save customer. Please try again."); }
        });
    }

    private TextField styledField(String value, String prompt) {
        TextField tf = new TextField(value);
        tf.setPromptText(prompt);
        tf.getStyleClass().add("text-field-custom");
        tf.setPrefWidth(260);
        return tf;
    }

    private Label boldLabel(String text) {
        Label l = new Label(text);
        l.setStyle("-fx-font-weight: bold; -fx-text-fill: #374151;");
        return l;
    }

    private Label errLabel() {
        Label l = new Label();
        l.setStyle("-fx-text-fill: #dc2626; -fx-font-size: 11px; -fx-padding: 0 0 4 0;");
        return l;
    }

    private void deleteCustomer(Customer c) {
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                "Delete customer: " + c.getName() + "?\nThis cannot be undone.", ButtonType.YES, ButtonType.NO);
        confirm.setTitle("Confirm Delete");
        confirm.setHeaderText(null);
        confirm.showAndWait().filter(r -> r == ButtonType.YES).ifPresent(r -> {
            if (dao.deleteCustomer(c.getCustomerId())) loadData();
            else showAlert(Alert.AlertType.ERROR, "Error", "Cannot delete customer with existing bookings.");
        });
    }

    private void showAlert(Alert.AlertType type, String title, String msg) {
        Alert a = new Alert(type, msg, ButtonType.OK);
        a.setTitle(title); a.setHeaderText(null); a.showAndWait();
    }

    public Parent getRoot() { return root; }
}
