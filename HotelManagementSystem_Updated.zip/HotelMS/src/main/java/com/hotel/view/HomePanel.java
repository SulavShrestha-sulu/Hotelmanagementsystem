package com.hotel.view;

import com.hotel.dao.BookingDAO;
import com.hotel.dao.CustomerDAO;
import com.hotel.dao.RoomDAO;
import com.hotel.model.Booking;
import com.hotel.util.SessionManager;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.util.List;

public class HomePanel {

    private ScrollPane root;
    private BookingDAO bookingDAO = new BookingDAO();
    private RoomDAO roomDAO = new RoomDAO();
    private CustomerDAO customerDAO = new CustomerDAO();
    private DashboardView dashboard;

    public HomePanel(DashboardView dashboard) {
        this.dashboard = dashboard;
        buildUI();
    }

    private void buildUI() {
        VBox content = new VBox(24);
        content.setPadding(new Insets(32));
        content.getStyleClass().add("panel-content");

        // Header
        Label title = new Label("Dashboard");
        title.getStyleClass().add("panel-title");
        String roleTag = SessionManager.isAdmin() ? " [Admin]" : " [Staff]";
        Label sub = new Label("Welcome back, " + SessionManager.getCurrentUser().getUsername() + roleTag
                + "! Here's what's happening today.");
        sub.getStyleClass().add("panel-subtitle");
        VBox header = new VBox(4, title, sub);

        // Stats cards
        HBox statsRow = new HBox(16);
        statsRow.setFillHeight(true);

        int totalRooms = roomDAO.totalRooms();
        int availRooms = roomDAO.countByStatus("Available");
        int todayBook  = bookingDAO.todayBookings();
        int totalBook  = bookingDAO.totalBookings();
        int totalCust  = customerDAO.totalCustomers();
        double revenue = bookingDAO.totalRevenue();

        statsRow.getChildren().addAll(
            statCard("🛏", "Total Rooms",      String.valueOf(totalRooms), availRooms + " Available", "#4f46e5"),
            statCard("📅", "Bookings Today",   String.valueOf(todayBook),  "Total: " + totalBook,     "#16a34a"),
            statCard("👥", "Total Customers",  String.valueOf(totalCust),  "All registered",          "#ea580c"),
            statCard("💰", "Revenue",          "Rs " + String.format("%,.0f", revenue), "All payments", "#0891b2")
        );
        for (var n : statsRow.getChildren()) HBox.setHgrow(n, Priority.ALWAYS);

        // Quick Actions + Recent Bookings
        HBox bottomRow = new HBox(16);
        bottomRow.setFillHeight(true);

        VBox quickActions  = buildQuickActions();
        VBox recentBookings = buildRecentBookings();
        HBox.setHgrow(quickActions, Priority.ALWAYS);
        HBox.setHgrow(recentBookings, Priority.ALWAYS);
        bottomRow.getChildren().addAll(quickActions, recentBookings);

        content.getChildren().addAll(header, statsRow, bottomRow);

        root = new ScrollPane(content);
        root.setFitToWidth(true);
        root.setStyle("-fx-background-color: transparent; -fx-background: transparent;");
    }

    private VBox statCard(String icon, String label, String value, String detail, String color) {
        VBox card = new VBox(8);
        card.getStyleClass().add("stat-card");
        card.setPadding(new Insets(20));

        Label iconLbl = new Label(icon);
        iconLbl.setStyle("-fx-font-size:28px; -fx-background-color:" + color +
                "; -fx-padding: 8; -fx-background-radius: 10;");

        Label valLbl = new Label(value);
        valLbl.setStyle("-fx-font-size:26px; -fx-font-weight:bold; -fx-text-fill: #1e1e2e;");

        Label nameLbl = new Label(label);
        nameLbl.setStyle("-fx-text-fill:#64748b; -fx-font-size:13px;");

        Label detailLbl = new Label(detail);
        detailLbl.setStyle("-fx-text-fill:" + color + "; -fx-font-size:11px; -fx-font-weight:bold;");

        card.getChildren().addAll(iconLbl, valLbl, nameLbl, detailLbl);
        return card;
    }

    private VBox buildQuickActions() {
        VBox box = new VBox(12);
        box.getStyleClass().add("card");
        box.setPadding(new Insets(20));

        Label title = new Label("Quick Actions");
        title.setStyle("-fx-font-size:16px; -fx-font-weight:bold; -fx-text-fill:#1e1e2e;");

        // icon, label, color, navigation target
        String[][] actions = {
            {"📅", "New Booking",   "#4f46e5", "bookings"},
            {"🛏", "Add Room",      "#16a34a", "rooms"},
            {"👤", "Add Customer",  "#ea580c", "customers"},
            {"📊", "View Reports",  "#0891b2", "reports"}
        };

        VBox list = new VBox(8);
        for (String[] a : actions) {
            HBox row = new HBox(12);
            row.setAlignment(Pos.CENTER_LEFT);
            row.setStyle("-fx-background-color: #f8fafc; -fx-background-radius:8; -fx-padding:12; -fx-cursor: hand;");

            Label ico = new Label(a[0]);
            ico.setStyle("-fx-font-size:18px;");
            Label lbl = new Label(a[1]);
            lbl.setStyle("-fx-font-weight:bold; -fx-text-fill:" + a[2] + ";");

            Label arrow = new Label("→");
            arrow.setStyle("-fx-text-fill:#cbd5e1;");
            Region spacer = new Region();
            HBox.setHgrow(spacer, Priority.ALWAYS);

            row.getChildren().addAll(ico, lbl, spacer, arrow);

            // Hover effect
            String normalStyle = "-fx-background-color: #f8fafc; -fx-background-radius:8; -fx-padding:12; -fx-cursor: hand;";
            String hoverStyle  = "-fx-background-color: #e0e7ff; -fx-background-radius:8; -fx-padding:12; -fx-cursor: hand;";
            row.setStyle(normalStyle);
            row.setOnMouseEntered(e -> row.setStyle(hoverStyle));
            row.setOnMouseExited(e -> row.setStyle(normalStyle));

            final String nav = a[3];
            row.setOnMouseClicked(e -> dashboard.navigateTo(nav));

            list.getChildren().add(row);
        }

        box.getChildren().addAll(title, new Separator(), list);
        return box;
    }

    private VBox buildRecentBookings() {
        VBox box = new VBox(12);
        box.getStyleClass().add("card");
        box.setPadding(new Insets(20));

        Label title = new Label("Recent Bookings");
        title.setStyle("-fx-font-size:16px; -fx-font-weight:bold; -fx-text-fill:#1e1e2e;");

        List<Booking> recent = bookingDAO.getRecentBookings(5);
        VBox list = new VBox(8);

        if (recent.isEmpty()) {
            Label empty = new Label("No bookings yet.");
            empty.setStyle("-fx-text-fill:#94a3b8;");
            list.getChildren().add(empty);
        } else {
            for (Booking b : recent) {
                HBox row = new HBox(10);
                row.setAlignment(Pos.CENTER_LEFT);
                row.setStyle("-fx-background-color:#f8fafc; -fx-background-radius:8; -fx-padding:10;");

                Label ico = new Label("📅");
                ico.setStyle("-fx-font-size:18px;");

                VBox info = new VBox(2);
                Label nm = new Label(b.getCustomerName());
                nm.setStyle("-fx-font-weight:bold; -fx-text-fill:#1e1e2e;");
                Label detail = new Label("Room " + b.getRoomNumber() + "  •  " + b.getCheckInDate());
                detail.setStyle("-fx-text-fill:#64748b; -fx-font-size:11px;");
                info.getChildren().addAll(nm, detail);

                Region spacer = new Region();
                HBox.setHgrow(spacer, Priority.ALWAYS);

                String statusColor = switch (b.getStatus()) {
                    case "Confirmed"  -> "#16a34a";
                    case "Cancelled"  -> "#dc2626";
                    default           -> "#0891b2";
                };
                Label status = new Label(b.getStatus());
                status.setStyle("-fx-text-fill:" + statusColor +
                        "; -fx-font-size:11px; -fx-font-weight:bold; -fx-background-color:" +
                        statusColor + "22; -fx-padding:3 8; -fx-background-radius:10;");

                row.getChildren().addAll(ico, info, spacer, status);
                list.getChildren().add(row);
            }
        }

        box.getChildren().addAll(title, new Separator(), list);
        return box;
    }

    public Parent getRoot() { return root; }
}
