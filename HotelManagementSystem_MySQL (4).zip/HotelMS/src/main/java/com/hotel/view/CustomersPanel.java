package com.hotel.view;

import com.hotel.dao.CustomerDAO;
import com.hotel.model.Customer;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;

public class CustomersPanel {

    private VBox root;
    private TableView<Customer> table;
    private ObservableList<Customer> data;
    private CustomerDAO dao = new CustomerDAO();
    private TextField searchField;

    public CustomersPanel() { buildUI(); }

    private void buildUI() {
        root = new VBox(20);
        root.setPadding(new Insets(32));
        root.getStyleClass().add("panel-content");

        Label title = new Label("Customer Management");
        title.getStyleClass().add("panel-title");
        Label sub = new Label("Manage all customer information and records");
        sub.getStyleClass().add("panel-subtitle");

        searchField = new TextField();
        searchField.setPromptText("🔍  Search by name, email, phone...");
        searchField.getStyleClass().add("search-field");
        searchField.setPrefWidth(300);
        searchField.textProperty().addListener((o, ov, nv) -> filterCustomers(nv));

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button addBtn = new Button("+ Add Customer");
        addBtn.getStyleClass().add("btn-primary");
        addBtn.setOnAction(e -> showDialog(null));

        HBox headerRow = new HBox(12, searchField, spacer, addBtn);
        headerRow.setAlignment(Pos.CENTER_LEFT);

        table = new TableView<>();
        table.getStyleClass().add("data-table");
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        VBox.setVgrow(table, Priority.ALWAYS);

        TableColumn<Customer, Integer> idCol = col("ID", "customerId");
        idCol.setMaxWidth(60);
        TableColumn<Customer, String> nameCol = col("Name", "name");
        TableColumn<Customer, String> phoneCol = col("Phone", "phone");
        TableColumn<Customer, String> emailCol = col("Email", "email");
        TableColumn<Customer, String> addrCol  = col("Address", "address");
        TableColumn<Customer, Integer> bookCol = col("Total Bookings", "totalBookings");
        bookCol.setMaxWidth(120);

        TableColumn<Customer, Void> actCol = new TableColumn<>("Actions");
        actCol.setCellFactory(col -> new TableCell<>() {
            final Button editBtn = new Button("✏ Edit");
            final Button delBtn  = new Button("🗑");
            { editBtn.getStyleClass().add("btn-sm-primary");
              delBtn.getStyleClass().add("btn-sm-danger"); }
            @Override protected void updateItem(Void v, boolean empty) {
                super.updateItem(v, empty);
                if (empty) { setGraphic(null); return; }
                HBox box = new HBox(6, editBtn, delBtn);
                editBtn.setOnAction(e -> showDialog(getTableView().getItems().get(getIndex())));
                delBtn.setOnAction(e -> deleteCustomer(getTableView().getItems().get(getIndex())));
                setGraphic(box);
            }
        });

        table.getColumns().addAll(idCol, nameCol, phoneCol, emailCol, addrCol, bookCol, actCol);
        loadData();

        root.getChildren().addAll(new VBox(4, title, sub), headerRow, table);
    }

    @SuppressWarnings("unchecked")
    private <T> TableColumn<Customer, T> col(String label, String prop) {
        TableColumn<Customer, T> c = new TableColumn<>(label);
        c.setCellValueFactory(new PropertyValueFactory<>(prop));
        return c;
    }

    private void loadData() {
        data = FXCollections.observableArrayList(dao.getAllCustomers());
        table.setItems(data);
    }

    private void filterCustomers(String query) {
        if (query == null || query.isBlank()) { loadData(); return; }
        data = FXCollections.observableArrayList(dao.searchCustomers(query));
        table.setItems(data);
    }

    private void showDialog(Customer existing) {
        Dialog<Customer> dialog = new Dialog<>();
        dialog.setTitle(existing == null ? "Add Customer" : "Edit Customer");
        dialog.setHeaderText(null);

        ButtonType saveType = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(saveType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(12); grid.setVgap(12);
        grid.setPadding(new Insets(20));

        TextField nameF  = field(existing != null ? existing.getName() : "");
        TextField phoneF = field(existing != null ? existing.getPhone() : "");
        TextField emailF = field(existing != null ? existing.getEmail() : "");
        TextField addrF  = field(existing != null ? existing.getAddress() : "");

        grid.addRow(0, new Label("Full Name:"), nameF);
        grid.addRow(1, new Label("Phone:"), phoneF);
        grid.addRow(2, new Label("Email:"), emailF);
        grid.addRow(3, new Label("Address:"), addrF);

        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getStylesheets().add(getClass().getResource("/styles/main.css").toExternalForm());

        dialog.setResultConverter(btn -> {
            if (btn == saveType) {
                Customer c = existing != null ? existing : new Customer();
                c.setName(nameF.getText().trim());
                c.setPhone(phoneF.getText().trim());
                c.setEmail(emailF.getText().trim());
                c.setAddress(addrF.getText().trim());
                return c;
            }
            return null;
        });

        dialog.showAndWait().ifPresent(c -> {
            if (c.getName().isEmpty() || c.getPhone().isEmpty()) {
                showAlert(Alert.AlertType.WARNING, "Validation", "Name and Phone are required.");
                return;
            }
            boolean ok = existing == null ? dao.addCustomer(c) : dao.updateCustomer(c);
            if (ok) { loadData(); showAlert(Alert.AlertType.INFORMATION, "Success", "Customer saved."); }
            else showAlert(Alert.AlertType.ERROR, "Error", "Could not save customer.");
        });
    }

    private TextField field(String value) {
        TextField tf = new TextField(value);
        tf.getStyleClass().add("text-field-custom");
        tf.setPrefWidth(250);
        return tf;
    }

    private void deleteCustomer(Customer c) {
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                "Delete customer: " + c.getName() + "?", ButtonType.YES, ButtonType.NO);
        confirm.showAndWait().filter(r -> r == ButtonType.YES).ifPresent(r -> {
            if (dao.deleteCustomer(c.getCustomerId())) loadData();
            else showAlert(Alert.AlertType.ERROR, "Error", "Cannot delete customer with bookings.");
        });
    }

    private void showAlert(Alert.AlertType type, String title, String msg) {
        Alert a = new Alert(type, msg, ButtonType.OK);
        a.setTitle(title); a.setHeaderText(null); a.showAndWait();
    }

    public Parent getRoot() { return root; }
}
