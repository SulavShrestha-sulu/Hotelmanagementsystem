package com.hotel.view;

import com.hotel.util.SessionManager;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class DashboardView {

    private BorderPane root;
    private Stage stage;
    private StackPane contentArea;
    private Button activeBtn;

    public DashboardView(Stage stage) {
        this.stage = stage;
        buildUI();
    }

    private void buildUI() {
        root = new BorderPane();
        root.getStyleClass().add("main-root");

        // Sidebar
        VBox sidebar = buildSidebar();
        root.setLeft(sidebar);

        // Content
        contentArea = new StackPane();
        contentArea.getStyleClass().add("content-area");
        root.setCenter(contentArea);

        // Default to home
        showHome();
    }

    private VBox buildSidebar() {
        VBox sidebar = new VBox(0);
        sidebar.getStyleClass().add("sidebar");
        sidebar.setPrefWidth(220);

        // Brand
        VBox brand = new VBox(2);
        brand.getStyleClass().add("sidebar-brand");
        brand.setPadding(new Insets(24, 16, 24, 16));
        Label icon = new Label("🏨");
        icon.setStyle("-fx-font-size: 28px;");
        Label name = new Label("Hotel Manager");
        name.getStyleClass().add("brand-name");
        Label sub = new Label("Management System");
        sub.getStyleClass().add("brand-sub");
        brand.getChildren().addAll(icon, name, sub);

        Separator sep = new Separator();
        sep.setStyle("-fx-background-color: rgba(255,255,255,0.15);");

        // Nav buttons
        Button homeBtn = navButton("  🏠  Dashboard", "dashboard");
        Button roomBtn = navButton("  🛏  Room Management", "rooms");
        Button custBtn = navButton("  👤  Customer Management", "customers");
        Button bookBtn = navButton("  📅  Bookings", "bookings");
        Button repBtn = navButton("  📊  Reports", "reports");

        homeBtn.setOnAction(e -> { setActive(homeBtn); showHome(); });
        roomBtn.setOnAction(e -> { setActive(roomBtn); showRooms(); });
        custBtn.setOnAction(e -> { setActive(custBtn); showCustomers(); });
        bookBtn.setOnAction(e -> { setActive(bookBtn); showBookings(); });
        repBtn.setOnAction(e -> { setActive(repBtn); showReports(); });

        setActive(homeBtn);

        // User info at bottom
        Region spacer = new Region();
        VBox.setVgrow(spacer, Priority.ALWAYS);

        VBox userBox = new VBox(4);
        userBox.setPadding(new Insets(12, 16, 8, 16));
        userBox.setStyle("-fx-border-color: rgba(255,255,255,0.15); -fx-border-width: 1 0 0 0;");
        Label userLbl = new Label("👤 " + SessionManager.getCurrentUser().getUsername());
        userLbl.setStyle("-fx-text-fill: #e0e0e0; -fx-font-weight: bold;");
        Label roleLbl = new Label(SessionManager.getCurrentUser().getRole());
        roleLbl.setStyle("-fx-text-fill: #a0a0a0; -fx-font-size: 11px;");
        userBox.getChildren().addAll(userLbl, roleLbl);

        Button logoutBtn = navButton("  🚪  Logout", "logout");
        logoutBtn.setOnAction(e -> logout());

        sidebar.getChildren().addAll(brand, sep,
                homeBtn, roomBtn, custBtn, bookBtn, repBtn,
                spacer, userBox, logoutBtn);
        return sidebar;
    }

    private Button navButton(String text, String id) {
        Button btn = new Button(text);
        btn.setId(id);
        btn.getStyleClass().add("nav-btn");
        btn.setMaxWidth(Double.MAX_VALUE);
        btn.setAlignment(Pos.CENTER_LEFT);
        return btn;
    }

    private void setActive(Button btn) {
        if (activeBtn != null) activeBtn.getStyleClass().remove("nav-btn-active");
        activeBtn = btn;
        btn.getStyleClass().add("nav-btn-active");
    }

    private void showHome() { contentArea.getChildren().setAll(new HomePanel().getRoot()); }
    private void showRooms() { contentArea.getChildren().setAll(new RoomsPanel().getRoot()); }
    private void showCustomers() { contentArea.getChildren().setAll(new CustomersPanel().getRoot()); }
    private void showBookings() { contentArea.getChildren().setAll(new BookingsPanel().getRoot()); }
    private void showReports() { contentArea.getChildren().setAll(new ReportsPanel().getRoot()); }

    private void logout() {
        SessionManager.logout();
        LoginView loginView = new LoginView(stage);
        Scene scene = new Scene(loginView.getRoot(), 420, 520);
        scene.getStylesheets().add(getClass().getResource("/styles/main.css").toExternalForm());
        stage.setScene(scene);
        stage.setResizable(false);
        stage.setWidth(420);
        stage.setHeight(520);
    }

    public Parent getRoot() { return root; }
}
