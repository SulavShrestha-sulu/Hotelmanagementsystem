package com.hotel.view;

import com.hotel.dao.BookingDAO;
import com.hotel.dao.CustomerDAO;
import com.hotel.dao.PaymentDAO;
import com.hotel.dao.RoomDAO;
import com.hotel.model.Payment;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;

import java.util.List;

public class ReportsPanel {

    private ScrollPane root;
    private BookingDAO bookingDAO = new BookingDAO();
    private RoomDAO roomDAO = new RoomDAO();
    private CustomerDAO customerDAO = new CustomerDAO();
    private PaymentDAO paymentDAO = new PaymentDAO();

    public ReportsPanel() { buildUI(); }

    private void buildUI() {
        VBox content = new VBox(24);
        content.setPadding(new Insets(32));
        content.getStyleClass().add("panel-content");

        Label title = new Label("Reports & Analytics");
        title.getStyleClass().add("panel-title");
        Label sub = new Label("View detailed statistics and performance metrics");
        sub.getStyleClass().add("panel-subtitle");

        // Summary stat cards
        HBox statsRow = new HBox(16);
        int totalRooms = roomDAO.totalRooms();
        int available  = roomDAO.countByStatus("Available");
        int booked     = roomDAO.countByStatus("Booked");
        int maint      = roomDAO.countByStatus("Maintenance");
        int totalBook  = bookingDAO.totalBookings();
        int totalCust  = customerDAO.totalCustomers();
        double revenue = bookingDAO.totalRevenue();
        double occupancy = totalRooms > 0 ? (booked * 100.0 / totalRooms) : 0;

        statsRow.getChildren().addAll(
            reportCard("💰", "Total Revenue", "Rs " + String.format("%,.0f", revenue), "#4f46e5"),
            reportCard("📅", "Total Bookings", String.valueOf(totalBook), "#16a34a"),
            reportCard("👥", "Total Customers", String.valueOf(totalCust), "#ea580c"),
            reportCard("📈", "Occupancy Rate", String.format("%.0f%%", occupancy), "#0891b2")
        );
        for (var n : statsRow.getChildren()) HBox.setHgrow(n, Priority.ALWAYS);

        // Room status breakdown
        HBox midRow = new HBox(16);
        VBox roomStatus = buildRoomStatusCard(available, booked, maint, totalRooms);
        VBox bookingStatus = buildBookingStatusCard();
        HBox.setHgrow(roomStatus, Priority.ALWAYS);
        HBox.setHgrow(bookingStatus, Priority.ALWAYS);
        midRow.getChildren().addAll(roomStatus, bookingStatus);

        // Payments table
        VBox paymentsSection = buildPaymentsTable();

        content.getChildren().addAll(new VBox(4, title, sub), statsRow, midRow, paymentsSection);

        root = new ScrollPane(content);
        root.setFitToWidth(true);
        root.setStyle("-fx-background-color:transparent; -fx-background:transparent;");
    }

    private VBox reportCard(String icon, String label, String value, String color) {
        VBox card = new VBox(10);
        card.getStyleClass().add("stat-card");
        card.setPadding(new Insets(20));

        Label ico = new Label(icon);
        ico.setStyle("-fx-font-size:26px; -fx-background-color:" + color +
                "; -fx-padding:8; -fx-background-radius:10;");
        Label val = new Label(value);
        val.setStyle("-fx-font-size:22px; -fx-font-weight:bold; -fx-text-fill:#1e1e2e;");
        Label lbl = new Label(label);
        lbl.setStyle("-fx-text-fill:#64748b; -fx-font-size:12px;");
        card.getChildren().addAll(ico, val, lbl);
        return card;
    }

    private VBox buildRoomStatusCard(int available, int booked, int maint, int total) {
        VBox card = new VBox(14);
        card.getStyleClass().add("card");
        card.setPadding(new Insets(20));

        Label title = new Label("Room Status Breakdown");
        title.setStyle("-fx-font-size:15px; -fx-font-weight:bold; -fx-text-fill:#1e1e2e;");

        card.getChildren().addAll(title, new Separator());

        String[][] rows = {
            {"🟢", "Available",   String.valueOf(available), "#16a34a"},
            {"🔴", "Booked",      String.valueOf(booked),    "#dc2626"},
            {"🟡", "Maintenance", String.valueOf(maint),     "#d97706"},
            {"⬜", "Total Rooms", String.valueOf(total),     "#4f46e5"},
        };
        for (String[] r : rows) {
            HBox row = new HBox(10);
            row.setAlignment(Pos.CENTER_LEFT);
            row.setStyle("-fx-background-color:#f8fafc; -fx-background-radius:8; -fx-padding:10;");
            Label ico = new Label(r[0]);
            ico.setStyle("-fx-font-size:16px;");
            Label lbl = new Label(r[1]);
            lbl.setStyle("-fx-text-fill:#1e1e2e; -fx-font-size:13px;");
            Region sp = new Region();
            HBox.setHgrow(sp, Priority.ALWAYS);
            Label val = new Label(r[2]);
            val.setStyle("-fx-font-weight:bold; -fx-text-fill:" + r[3] + "; -fx-font-size:16px;");
            row.getChildren().addAll(ico, lbl, sp, val);
            card.getChildren().add(row);
        }
        return card;
    }

    private VBox buildBookingStatusCard() {
        VBox card = new VBox(14);
        card.getStyleClass().add("card");
        card.setPadding(new Insets(20));

        Label title = new Label("Booking Summary");
        title.setStyle("-fx-font-size:15px; -fx-font-weight:bold; -fx-text-fill:#1e1e2e;");

        List<Payment> payments = paymentDAO.getAllPayments();
        double totalPaid = payments.stream().mapToDouble(Payment::getAmount).sum();
        int totalBook = bookingDAO.totalBookings();
        int todayBook = bookingDAO.todayBookings();

        card.getChildren().addAll(title, new Separator());

        String[][] rows = {
            {"📅", "Total Bookings",    String.valueOf(totalBook),                           "#4f46e5"},
            {"🏨", "Today's Bookings",  String.valueOf(todayBook),                           "#16a34a"},
            {"💳", "Total Payments",    String.valueOf(payments.size()),                     "#ea580c"},
            {"💰", "Total Collected",   "Rs " + String.format("%,.0f", totalPaid),          "#0891b2"},
        };
        for (String[] r : rows) {
            HBox row = new HBox(10);
            row.setAlignment(Pos.CENTER_LEFT);
            row.setStyle("-fx-background-color:#f8fafc; -fx-background-radius:8; -fx-padding:10;");
            Label ico = new Label(r[0]);
            ico.setStyle("-fx-font-size:16px;");
            Label lbl = new Label(r[1]);
            lbl.setStyle("-fx-text-fill:#1e1e2e; -fx-font-size:13px;");
            Region sp = new Region();
            HBox.setHgrow(sp, Priority.ALWAYS);
            Label val = new Label(r[2]);
            val.setStyle("-fx-font-weight:bold; -fx-text-fill:" + r[3] + "; -fx-font-size:14px;");
            row.getChildren().addAll(ico, lbl, sp, val);
            card.getChildren().add(row);
        }
        return card;
    }

    private VBox buildPaymentsTable() {
        VBox section = new VBox(12);
        section.getStyleClass().add("card");
        section.setPadding(new Insets(20));

        Label title = new Label("Payment History");
        title.setStyle("-fx-font-size:15px; -fx-font-weight:bold; -fx-text-fill:#1e1e2e;");

        TableView<Payment> table = new TableView<>();
        table.getStyleClass().add("data-table");
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        table.setPrefHeight(250);

        TableColumn<Payment, Integer> idCol     = col("Pay ID",   "paymentId");   idCol.setMaxWidth(70);
        TableColumn<Payment, Integer> bookCol   = col("Book ID",  "bookingId");   bookCol.setMaxWidth(80);
        TableColumn<Payment, String>  custCol   = col("Customer", "customerName");
        TableColumn<Payment, String>  roomCol   = col("Room",     "roomNumber");  roomCol.setMaxWidth(80);
        TableColumn<Payment, String>  dateCol   = col("Date",     "paymentDate");
        TableColumn<Payment, String>  methodCol = col("Method",   "paymentMethod");

        TableColumn<Payment, Double> amtCol = new TableColumn<>("Amount");
        amtCol.setCellValueFactory(new PropertyValueFactory<>("amount"));
        amtCol.setCellFactory(c -> new TableCell<>() {
            @Override protected void updateItem(Double v, boolean empty) {
                super.updateItem(v, empty);
                setText(empty || v == null ? null : "Rs " + String.format("%,.0f", v));
            }
        });

        table.getColumns().addAll(idCol, bookCol, custCol, roomCol, dateCol, methodCol, amtCol);
        table.setItems(FXCollections.observableArrayList(paymentDAO.getAllPayments()));

        section.getChildren().addAll(title, new Separator(), table);
        return section;
    }

    @SuppressWarnings("unchecked")
    private <T> TableColumn<Payment, T> col(String label, String prop) {
        TableColumn<Payment, T> c = new TableColumn<>(label);
        c.setCellValueFactory(new PropertyValueFactory<>(prop));
        return c;
    }

    public Parent getRoot() { return root; }
}
